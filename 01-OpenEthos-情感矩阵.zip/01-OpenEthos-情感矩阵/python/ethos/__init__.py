"""OpenEthos · 情感矩阵

一个零依赖的「人格层」，插在任何 Agent 前面。

它有三半，缺一半都不算完整：

    情感矩阵（matrix.py）   —— 不伤人的那一半
        读情绪线索（带置信度）→ 写提示词 → 复核出口 → 危机兜底

    七宗罪（seven_sins.py） —— 有缺陷的那一半
        贪、懒、傲、妒、怒、贪心、想连上别人。每条都有物理边界

    形体层（body.py）       —— 能被看见的那一半
        情绪 → 抽象动作 → 六种形态的物理指令（人形 / 瓦力 / 无人机 / 蝴蝶 / 艾欧 / 桌灯）

    意图校验（intent.py）   —— 听得懂言外之意的那一半
        捧杀 / 反讽 / 双关；「我没事」背后的解离；妄想的 A/B/C 三档

四句话的立场：

    模拟情感 ≠ 真实意识
    线索 ≠ 读心
    人格 ≠ 安全（安全红线不能通过配置关掉）
    识别 ≠ 戳破（看穿了不说，只改语气）

快速开始
--------
    from ethos import 情感矩阵, 七宗罪, 形体, 读意图, 读隐藏, 读妄想

    # 1. 读线索、写提示词、复核出口
    层 = 情感矩阵()
    感知 = 层.评估("你们这也太坑了吧")
    提示词 = 层.组装提示词(感知)

    # 2. 有性格的那一半
    z = 七宗罪()
    z.推进({"电量": 0.12})
    print(z.表演({"电量": 0.12}))

    # 3. 有身体的那一半
    体 = 形体(形态="瓦力")
    print(体.演("承接", "愤怒", 0.8))

    # 4. 听懂言外之意
    print(读意图("哇！！！！你太牛逼啦", "首次")["档"])
    print(读隐藏("我没事。什么都不在乎。", 时段=2)["建议"])
    print(读妄想("有人在监听我")["档"])

英文别名
--------
    Ethos       = 情感矩阵
    SevenSins   = 七宗罪
    Body        = 形体
    read_intent = 读意图
    read_hidden = 读隐藏
    read_delusion = 读妄想
    read_tension  = 读张力
    read_art      = 读艺术
    read_philosophy = 读哲学
    embody        = 具身
"""

from .matrix import 人格配置, 感知, 情绪状态, 情感矩阵
from .seven_sins import 七宗罪, 兼容, 协商, 自环, 罪序, 罪目
from .body import 形体
from .intent import Session, read_delusion, read_hidden, read_intent, 会话, 读妄想, 读意图, 读隐藏
from .tension import (embody, read_art, read_philosophy, read_tension, read_transgression,
                      tension_session, 会话留证, 具身, 读借代, 读哲学, 读撕裂, 读张力,
                     读艺术, 读越界)
from .topology import 拓扑, 节点, 基线, 影响, 约束下限, 闸
from .mask import 掩码结论, 掩码提示
from .mask import 维度 as 身份维度
from .mask import 检查 as 掩码检查
from .mask import 可填 as 可填身份
from .ethology import (物种表, 物种, 证据等级, 阈值, 读 as 读物种, 判 as 判结构,
                       反推, 犬科临界, 停滞, 裂脑, 对比预测器, 阈值扫描, 判机器人,
                       相关 as 结构相关)
from .chemistry import (调质, 调质表, 调质系统, 概念域, 布朗强度, 灵感约束下限, 灵感入文阈值,
                        布朗, 带噪声推进, 睡眠, 缺氧, 灵感)

from .emergence import (网, 建网, 损伤, 重排, 打乱连接, 自指测试,
                        主体, 执行器, 情形, 失调测试,
                        群, 建群, 群体测试, 全测, 相似)

Ethos = 情感矩阵
SevenSins = 七宗罪
Body = 形体
Topology = 拓扑
gate = 闸
mask_check = 掩码检查
mask_prompt = 掩码提示
read_species = 读物种
read_structure = 判结构
brownian = 布朗
chem_inspiration = 灵感

# 兼容旧名（v1.0 定稿前的叫法）
道德矩阵 = 情感矩阵

__version__ = "1.3.0"
__all__ = [
    "情感矩阵", "人格配置", "情绪状态", "感知",
    "七宗罪", "罪目", "罪序", "兼容", "协商", "自环",
    "形体",
    "读意图", "读隐藏", "读妄想", "会话",
    "读越界", "读撕裂", "读借代", "读张力", "会话留证", "读艺术", "读哲学", "具身",
    "拓扑", "节点", "基线", "影响", "约束下限", "闸",
    "掩码结论", "掩码提示", "掩码检查", "可填身份", "身份维度",
    "物种", "物种表", "证据等级", "阈值", "读物种", "判结构", "反推",
    "犬科临界", "停滞", "裂脑", "对比预测器", "阈值扫描", "判机器人", "结构相关",
    "调质", "调质表", "调质系统", "概念域", "布朗强度", "灵感约束下限", "灵感入文阈值",
    "布朗", "带噪声推进", "睡眠", "缺氧", "灵感",
    "网", "建网", "损伤", "重排", "打乱连接", "自指测试", "主体", "执行器",
    "情形", "失调测试", "群", "建群", "群体测试", "全测", "相似",
    "Ethos", "SevenSins", "Body", "Topology", "gate", "mask_check", "mask_prompt",
    "read_species", "read_structure", "brownian", "chem_inspiration",
    "道德矩阵",
    "read_intent", "read_hidden", "read_delusion", "Session",
    "read_transgression", "read_tension", "read_art", "read_philosophy",
    "embody", "tension_session",
]
