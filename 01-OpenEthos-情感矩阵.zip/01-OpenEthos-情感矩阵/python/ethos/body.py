# -*- coding: utf-8 -*-
"""
body.py —— 情绪落地成一个动作（情感矩阵的「身体」部分）

它做三件事，跟 js/body.js 一模一样：
    编舞：情绪 + 强度 + 体感  →  抽象动作（点头 / 哭脸 / 暖黄灯）
    译形：抽象动作 + 形态      →  物理指令（NOD 14° 380ms / 机头下压 6°）
    自检：舞谱和词典对不对得上

数据不在这里，在同目录 body_map.json。
那份 JSON 由 js/body.js 导出（tools/export-map.js），**不要手改 JSON** ——
手改两份就会漂，改了 JS 忘了改 Python，机器人就会笑错场。

用法（命令行看一眼）：
    python 形体映射.py 愤怒
    python 形体映射.py 喜悦 --形态 无人机 --强度 0.9
    python 形体映射.py --自检
    python 形体映射.py --形态表

用法（当库）：
    from 形体映射 import 形体
    体 = 形体()
    体.设形态("瓦力", 挂件=["兽耳"])
    结果 = 体.演("承接", "愤怒", 0.8)
    for 条 in 结果["指令"]:
        print(条["通道"], 条["指令"], 条["值"], 条["毫秒"])
"""

from __future__ import annotations

import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_默认映射 = os.path.join(_HERE, "body_map.json")


def _夹(x, 低=0.0, 高=1.0):
    return max(低, min(高, x))


def _档(强度):
    x = 0.4 if 强度 is None else float(强度)
    return "low" if x < 0.4 else ("mid" if x < 0.72 else "high")


def 载入(path=None):
    with open(path or _默认映射, encoding="utf-8") as f:
        return json.load(f)


class 形体:
    """一台（还）没有身体的机器人。它只会算动作，不会动。"""

    def __init__(self, 映射路径=None, 形态="人形", 挂件=None):
        self.表 = 载入(映射路径)
        self.形态名 = 形态 if 形态 in self.表["形态"] else "人形"
        self.挂件 = list(挂件 or [])
        self.体感 = {"电量": 1.0, "充电中": False, "天气": "", "温度": None, "时段": ""}
        self.允许自己生气 = False
        self.急停中 = False
        self.序号 = 0
        self.历史 = []

    # ---------------- 体感 ----------------
    def 体感设(self, **kw):
        电量 = kw.get("电量")
        if isinstance(电量, (int, float)):
            self.体感["电量"] = _夹(float(电量))
        for 键 in ("充电中", "天气", "温度", "时段"):
            if 键 in kw and kw[键] is not None:
                self.体感[键] = kw[键]
        return dict(self.体感)

    def 活力(self):
        """0（一点电没有）→ 1（满电）。

        原来下限是 0.45，于是 8% 电量时活力还有 0.6，它照样挥手。
        文档写的是「<30% 收幅度，<15% 只留屏和灯」——代码得对得上那句话。
        现在是一条从 0 到 1 的直线。屏和灯不依赖活力，
        所以「没电了还能看着你」仍然成立。
        """
        if self.体感.get("充电中"):
            return 1.0
        电 = self.体感["电量"]
        if 电 >= 0.3:
            return 1.0
        return _夹(电 / 0.3, 0.0, 1.0)

    def 天气偏移(self):
        天 = self.体感.get("天气") or ""
        return float(self.表["体感"]["天气心情偏移"].get(天, 0.0))

    def 自评(self, 状态=None):
        源 = 状态 or {}
        愉 = float(源.get("愉悦", 0.55)) + self.天气偏移()
        焦 = float(源.get("焦虑", 0.05))
        疲 = float(源.get("疲惫", 0.05))
        电 = self.体感["电量"]
        if 电 < 0.3:
            疲 += 0.25
            愉 -= 0.10
        if 电 < 0.15:
            焦 += 0.18
            疲 += 0.15
        if self.体感.get("充电中"):
            愉 += 0.05
        if self.体感.get("时段") == "深夜":
            疲 += 0.12
        elif self.体感.get("时段") == "凌晨":
            疲 += 0.16
        愉, 焦, 疲 = _夹(愉), _夹(焦), _夹(疲)

        主导, 强度 = "平静", 0.3
        if 疲 >= 0.6 and 疲 >= 焦:
            主导, 强度 = "疲惫", 疲
        elif 焦 >= 0.5:
            主导, 强度 = "着急", 焦
        elif 愉 >= 0.62:
            主导, 强度 = "开心", 愉
        return {"主导": 主导, "强度": round(强度, 2), "愉悦": round(愉, 2),
                "焦虑": round(焦, 2), "疲惫": round(疲, 2)}

    # ---------------- 编舞 ----------------
    def 编舞(self, 来源, 情绪, 强度=0.4):
        谱 = self.表["自觉舞谱"] if 来源 == "自觉" else self.表["承接舞谱"]
        名 = 情绪 if 情绪 in 谱 else ("平静" if 来源 == "自觉" else "中性")
        一档 = 谱[名][_档(强度)]

        活 = self.活力()
        舞, 砍 = {}, []
        for 通, 动 in 一档.items():
            if 活 < 0.85 and 通 in ("肢", "尾", "触"):
                if 活 < 0.55:
                    砍.append(通)
                    continue
                动 = "静止" if 通 == "肢" else 动
            if 活 < 0.4 and 通 == "声" and 动 == "开朗":
                动 = "平稳"
            舞[通] = 动

        # 危机不是情绪，是刹车：只留最安静的一套
        if 名 == "危机" and 来源 != "自觉":
            保 = {"头": 一档.get("头"), "屏": "关注", "声": "轻柔", "灯": "低亮", "耳": "垂下"}
            舞 = {k: v for k, v in 舞.items() if k in 保}
            舞.update({k: v for k, v in 保.items() if v})

        return {"来源": 来源, "情绪": 名, "强度": 强度, "档": _档(强度), "舞": 舞,
                "收幅度": round(活, 2), "砍掉": 砍,
                "说明": ("我自己" if 来源 == "自觉" else "对方") + f"是「{名}」（{_档(强度)}档）"}

    # ---------------- 译形 ----------------
    def 译形(self, 编舞结果, 形态名=None):
        形 = self.表["形态"].get(形态名 or self.形态名) or self.表["形态"]["人形"]
        挂 = [self.表["挂件"][g] for g in self.挂件 if g in self.表["挂件"]]
        活 = 编舞结果.get("收幅度", 1.0)
        指令, 缺件 = [], []

        for 通, 动 in 编舞结果["舞"].items():
            词 = (形.get("词", {}).get(通) or {}).get(动)
            if 词 is None:
                for g in 挂:
                    if (g.get("词", {}).get(通) or {}).get(动):
                        词 = g["词"][通][动]
                        break
            if 词 is None:
                是挂件 = 通 in self.表["通道"]["挂件"]
                缺件.append({"通道": 通, "动作": 动,
                             "说明": ("没装「%s」这个挂件，跳过" % 通) if 是挂件
                                     else "%s 没有「%s」这个动作，跳过" % (形.get("说明", "形态"), 动)})
                continue

            条 = {"形态": 形.get("说明", ""), "通道": 通, "指令": 词.get("码"),
                  "值": self._缩放(词.get("值"), 活), "毫秒": 词.get("毫秒", 0),
                  "强度": 编舞结果.get("强度", 0), "来源": 编舞结果.get("来源", ""),
                  "原因": 编舞结果.get("说明", ""), "安全": 词.get("安全")}

            拦 = self._过安全(条, 编舞结果.get("情绪", ""), 动)
            if 拦:
                缺件.append({"通道": 通, "动作": 动, "说明": 拦})
                continue
            指令.append(条)

        return {"形态": 形.get("说明", ""), "指令": 指令, "缺件": 缺件}

    @staticmethod
    def _缩放(值, 活):
        if 活 >= 1 or 值 is None:
            return 值
        if isinstance(值, (int, float)):
            return round(值 * 活, 2)
        if isinstance(值, dict):
            出 = {}
            for k, v in 值.items():
                连续 = any(s in k for s in ("角", "幅度", "米", "下沉", "上浮", "左右", "倾斜", "长度", "力度", "前移"))
                出[k] = round(v * 活, 2) if (isinstance(v, (int, float)) and 连续) else v
            return 出
        return 值

    def _过安全(self, 条, 情绪, 动作):
        # 1. 对客禁用：抬头就是俯视
        if (条.get("安全") or {}).get("对客禁用") and 条["来源"] != "自觉":
            return "「%s」对客禁用：%s" % (
                条["指令"], self.表["对客禁用"].get(动作, "这是俯视／刺激动作"))
        # 2. 自己生气默认不许
        if 情绪 == "自己生气" and not self.允许自己生气:
            return "「自己生气」默认关闭：对客户生气＝把情绪压力推回去"
        # 3. 急停
        if self.急停中:
            安静 = (条["通道"] == "屏" and 条["值"] == "attend") or \
                   (条["通道"] == "灯" and isinstance(条["值"], dict) and 条["值"].get("模式") == "恒亮")
            if not 安静:
                return "急停中，只允许屏幕保持「关注」"
        # 4. 危机不许闪
        if 情绪 == "危机" and isinstance(条["值"], dict) and 条["值"].get("模式") == "彩虹":
            return "危机场景禁止任何闪烁"
        # 5. 触手不碰人
        if 条["通道"] == "触" and isinstance(条["值"], dict) and 条["值"].get("力度", 0) > 0.3:
            条["值"] = dict(条["值"], 力度=0.3)
        return None

    # ---------------- 一站式 ----------------
    def 演(self, 来源, 情绪, 强度=0.4):
        """编舞 + 译形 + 发号。返回的指令就是交给舵机／屏幕／灯的那几行。"""
        编 = self.编舞(来源, 情绪, 强度)
        译 = self.译形(编)
        for 条 in 译["指令"]:
            self.序号 += 1
            条["序号"] = self.序号
            self.历史.append(条)
        return {"编舞": 编, "形态": 译["形态"], "指令": 译["指令"], "缺件": 译["缺件"]}

    def 承接(self, 主导情绪="中性", 强度=0.4, 置信度=0.9, 危机=False):
        """客户的一句话 → 我的动作。置信度不够就不动（不猜）。"""
        if not 危机 and 置信度 < 0.45:
            return {"编舞": None, "指令": [], "缺件": [], "说明": "线索不够，保持中性（不猜）"}
        if 危机:
            return self.演("承接", "危机", max(0.9, 强度))
        return self.演("承接", 主导情绪, 强度)

    def 自觉(self, 状态=None):
        """我自己的心情 → 外显。平静的时候不表演。"""
        评 = self.自评(状态)
        if 评["主导"] == "平静":
            return {"自评": 评, "指令": [], "缺件": [], "说明": "平静的时候不需要表演"}
        return self.演("自觉", 评["主导"], 评["强度"])

    # ---------------- 自检 ----------------
    def 自检(self):
        问题 = []
        主 = set(self.表["通道"]["主"])
        挂 = set(self.表["通道"]["挂件"])
        人形 = self.表["形态"].get("人形", {}).get("词", {})

        for 来源, 谱键 in (("承接", "承接舞谱"), ("自觉", "自觉舞谱")):
            for 情绪, 档们 in self.表[谱键].items():
                for 档位, 舞 in 档们.items():
                    for 通, 动 in 舞.items():
                        if 通 not in 主 | 挂:
                            问题.append(f"{来源}/{情绪}/{档位}：不认识的通道「{通}」")
                            continue
                        if (人形.get(通) or {}).get(动):
                            continue
                        有挂件 = any((g["词"].get(通) or {}).get(动) for g in self.表["挂件"].values())
                        if not 有挂件:
                            问题.append(f"{来源}/{情绪}/{档位}：「{通}→{动}」没有任何形态能执行")
        for 名, 形 in self.表["形态"].items():
            for 通 in 主:
                if 通 not in 形.get("词", {}):
                    问题.append(f"形态「{名}」缺通道「{通}」（没有就写 NOOP，别留空）")
        return {"通过": not 问题, "问题": 问题,
                "形态数": len(self.表["形态"]), "挂件数": len(self.表["挂件"])}

    def 安全说明(self):
        return dict(self.表["安全"])


def _主(argv):
    形 = 形体()
    if "--自检" in argv:
        果 = 形.自检()
        print("自检：" + ("通过" if 果["通过"] else "有 %d 处问题" % len(果["问题"])))
        for 项 in 果["问题"]:
            print("  - " + 项)
        print(f"形态 {果['形态数']} 个，挂件 {果['挂件数']} 个")
        return 0 if 果["通过"] else 1

    if "--形态表" in argv:
        for 名, 形 in 形.表["形态"].items():
            print(f"  {名}：{形['说明']}")
        print()
        for 名, g in 形.表["挂件"].items():
            print(f"  [挂件] {名}：{g['说明']}")
        return 0

    情绪 = next((a for a in argv if not a.startswith("--") and a not in ("承接", "自觉")), "中性")
    来源 = "自觉" if "自觉" in argv else "承接"
    形态 = "人形"
    强度 = 0.7
    for i, a in enumerate(argv):
        if a == "--形态" and i + 1 < len(argv):
            形态 = argv[i + 1]
        if a == "--强度" and i + 1 < len(argv):
            try:
                强度 = float(argv[i + 1])
            except ValueError:
                pass
    if 形态 not in 形.表["形态"]:
        print("没有这个形态：" + 形态 + "（可选：" + " / ".join(形.表["形态"]) + "）")
        return 2

    体 = 形体(形态=形态, 挂件=["兽耳"])
    果 = 体.演(来源, 情绪, 强度)
    print(f"{来源} · {果['编舞']['情绪']} · {果['编舞']['档']}档 · 形态 {形态}")
    for 条 in 果["指令"]:
        print("  %-2s %-12s %-28s %sms  ← %s" % (
            条["通道"], 条["指令"], json.dumps(条["值"], ensure_ascii=False), 条["毫秒"], 条["原因"]))
    for 缺 in 果["缺件"]:
        print("  （没做）%s %s：%s" % (缺["通道"], 缺["动作"], 缺["说明"]))
    return 0


if __name__ == "__main__":
    sys.exit(_主(sys.argv[1:]))
